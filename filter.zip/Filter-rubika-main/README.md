#  ꯭҉➺꯭͡͝༒꯭꯭꯭꯭͡͝-🅡꯭͡͝-🅐꯭͡͝-🅜꯭͡͝-🅘꯭͡͝-🅝꯭͡͝-🅞꯭͡͝-🅚꯭͡͝༒҉꯭͡͝☬꯭  
apt update

apt upgrade

pkg install python

pkg install git 

git clone url ?

python filter.py
